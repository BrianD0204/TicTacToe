package com.example.tictactoe

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.GridLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class GameActivity : AppCompatActivity() {
    private lateinit var gameBoard: GridLayout
    private var currentPlayer = "X"
    private val boardSize = 3
    private var gameState = Array(3) { arrayOfNulls<String>(3) }
    private var gameActive = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
        gameBoard = findViewById(R.id.gameBoard)
        initializeGameBoard()
    }

    private fun initializeGameBoard() {
        for (i in 0 until boardSize) {
            for (j in 0 until boardSize) {
                val button = Button(this).apply {
                    textSize = 24f
                    setOnClickListener {
                        if (gameActive && text.isEmpty()) {
                            text = currentPlayer
                            gameState[i][j] = currentPlayer
                            if (checkForWin() || isBoardFull()) {
                                gameActive = false
                                val winner = if (checkForWin()) currentPlayer else "Draw"
                                GameHistory.addResult(GameResult(winner, gameState))
                                showResult(winner)
                            } else {
                                currentPlayer = if (currentPlayer == "X") "O" else "X"
                            }
                        }
                    }
                }
                gameBoard.addView(button, GridLayout.LayoutParams().apply {
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    width = 0
                    height = 0
                    rightMargin = 5
                    topMargin = 5
                    bottomMargin = 5
                    leftMargin = 5
                })
            }
        }
    }

    private fun checkForWin(): Boolean {
        val lines = listOf(
            Triple(0, 0, 1), Triple(0, 1, 1), Triple(0, 2, 1),
            Triple(0, 0, 0), Triple(1, 0, 0), Triple(2, 0, 0),
            Triple(0, 0, 2), Triple(0, 2, 2)
        )
        lines.forEach { (startX, startY, direction) ->
            var x = startX
            var y = startY
            val first = gameState[x][y]
            var count = 0
            while (x in 0..2 && y in 0..2 && gameState[x][y] == first) {
                count++
                x += if (direction == 1) 1 else if (direction == 0) 0 else if (y == 0) 1 else -1
                y += if (direction == 1) 0 else if (direction == 2 && x != 1) -1 else 1
            }
            if (count == 3 && first != null) return true
        }
        return false
    }

    private fun isBoardFull(): Boolean = gameState.all { row -> row.all { it != null } }
    private fun showResult(winner: String) {
        Toast.makeText(this, "$winner wins!", Toast.LENGTH_LONG).apply {
            setGravity(Gravity.CENTER, 0, 0)
            show()
        }
    }
}
