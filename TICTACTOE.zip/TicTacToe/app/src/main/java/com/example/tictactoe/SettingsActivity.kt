package com.example.tictactoe

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        sharedPreferences = getSharedPreferences("TicTacToeSettings", MODE_PRIVATE)
        val playersGroup: RadioGroup = findViewById(R.id.playersGroup)
        val firstMoveGroup: RadioGroup = findViewById(R.id.firstMoveGroup)


        val numPlayers = sharedPreferences.getInt("numPlayers", 1)
        if (numPlayers == 1) {
            playersGroup.check(R.id.onePlayer)
        } else {
            playersGroup.check(R.id.twoPlayers)
        }

        val firstMove = sharedPreferences.getString("firstMove", "X")
        if (firstMove == "X") {
            firstMoveGroup.check(R.id.firstMoveX)
        } else {
            firstMoveGroup.check(R.id.firstMoveO)
        }

        playersGroup.setOnCheckedChangeListener { _, checkedId ->
            with(sharedPreferences.edit()) {
                putInt("numPlayers", if (checkedId == R.id.onePlayer) 1 else 2)
                apply()
            }
        }

        firstMoveGroup.setOnCheckedChangeListener { _, checkedId ->
            with(sharedPreferences.edit()) {
                putString("firstMove", if (checkedId == R.id.firstMoveX) "X" else "O")
                apply()
            }
        }

    }
}
