package com.example.tictactoe

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val historyContainer: LinearLayout = findViewById(R.id.historyContainer)

        GameHistory.results.forEach { result ->
            val textView = TextView(this).apply {
                text = "Winner ${result.winner}\nBoard State: ${result.gameState.contentDeepToString()}"
                textSize = 16f
            }
            historyContainer.addView(textView)
        }
    }
}
