package com.example.tictactoe

object GameHistory {
    val results = mutableListOf<GameResult>()

    fun addResult(result: GameResult) {
        results.add(result)
    }
}
