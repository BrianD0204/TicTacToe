package com.example.tictactoe

data class GameResult(val winner: String, val gameState: Array<Array<String?>>)

